from threading import Thread
import os
def func1():
    os.system('python3 main.py')

def func2():
    os.system('python3 app.py')
def func3():
    os.system('python3 ngrok.py')

if __name__ == '__main__':
    Thread(target = func1).start()
    Thread(target = func2).start()
    Thread(target = func3).start()