import cv2
from datetime import datetime
class VideoCamera(object):
    def __init__(self):
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.org = (50, 50)
        self.org1 = (50, 100)
        self.color = (255, 255, 0)
        self.thickness = 2
        self.fontScale = 1
        self.video = cv2.VideoCapture(0)
        

    def __del__(self):
        self.video.release()        

    def get_frame(self):
        ret, frame = self.video.read()
        t1 = "t1 :" + str(datetime.now())
       
       
        resized = cv2.resize(frame, (1280,960))
        t2 = "t2 :" +  str(datetime.now())
        resized = cv2.putText(resized, t1, self.org, self.font, self.fontScale, self.color)
        resized = cv2.putText(resized, t2, self.org1, self.font, self.fontScale, self.color)

        ret, jpeg = cv2.imencode('.jpeg', resized)
        
        
        return jpeg.tobytes()