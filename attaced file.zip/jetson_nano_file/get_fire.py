import firebase_admin
from firebase_admin import credentials,db
import time

class fire:
    def __init__(self,credentials_path):
        self.cd = credentials.Certificate(credentials_path)

        firebase_admin.initialize_app(self.cd, {'databaseURL': 'https://rbo1-5778c-default-rtdb.firebaseio.com'})

    def get(self):
        self.ref = db.reference('control/control/s1')
        return self.ref.get()
        
    def send(self,dir,data):
        self.data = data
        self.ref = db.reference('control/control')
        self.ref.child(dir).set(data)
        
        