import Jetson.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)


GPIO.setwarnings(False)
# left motor 18,37
# right motor 19,38

GPIO.setup(18, GPIO.OUT) #output 1 
GPIO.setup(19, GPIO.OUT) #output 3
GPIO.setup(37, GPIO.OUT) #output 2
GPIO.setup(38, GPIO.OUT) #output 4

def forward():
    GPIO.output(18,GPIO.LOW)
    GPIO.output(19,GPIO.LOW) 
    GPIO.output(37,GPIO.HIGH)
    GPIO.output(38,GPIO.HIGH) 


def backward():
    GPIO.output(18,GPIO.HIGH)
    GPIO.output(19,GPIO.HIGH) 
    GPIO.output(37,GPIO.LOW)
    GPIO.output(38,GPIO.LOW)

def left():
    GPIO.output(18,GPIO.LOW)
    GPIO.output(19,GPIO.LOW) 
    GPIO.output(37,GPIO.HIGH)
    GPIO.output(38,GPIO.LOW) 

def right():
    GPIO.output(18,GPIO.LOW)
    GPIO.output(19,GPIO.LOW) 
    GPIO.output(37,GPIO.LOW)
    GPIO.output(38,GPIO.HIGH) 

def stop():
    GPIO.output(18,GPIO.LOW)
    GPIO.output(19,GPIO.LOW) 
    GPIO.output(37,GPIO.LOW)
    GPIO.output(38,GPIO.LOW) 
# def main():

#     forward()
#     time.sleep(3)
#     backward()
#     time.sleep(3)
#     left()
#     time.sleep(3)
#     right()
#     time.sleep(3)
#     stop()

    
#     # try:

#     #     while 1:
            
            
#     # finally:
#     #     GPIO.cleanup() 

   



# if __name__ == '__main__':
#     main()