import json
import get_fire
import os
import subprocess
import time
import netifaces
import socket

while 1:
  try:	
    address = netifaces.ifaddresses('wlan0')
    address = address[2]
    address = address[0]
    address = address['addr']
    
    print(address)
    break
  except:
    print("error")
    pass
  

s = get_fire.fire("/home/lutfi/program_kp/rbo1-5778c-firebase-adminsdk-h63az-36a1ec0554.json")

#msg = "ngrok URL's: \n"
msg = ""


s.send('addres',address)

