from firebase import Firebase

config = {
  "apiKey": "AAAAEo4OEJM:APA91bEbZ0E354ZtPdnC20_4qZz3oPuw0LX1E2vWuwGKNCpPCvc5vlc4GReL85CZOPavOdL-knpPH7Y_7vcHJyJib672nURdEGotEp0Cs4ZAczRIUwIWHqCe8D66EQMGGl9FitRZoSF6	",
  "authDomain": "projectId.firebaseapp.com",
  "databaseURL": "https://rbo1-5778c-default-rtdb.firebaseio.com",
  "serviceAccount": "/home/lutfi/program_kp/rbo1-5778c-firebase-adminsdk-h63az-392959c4d8.json"
}

firebase = Firebase(config)