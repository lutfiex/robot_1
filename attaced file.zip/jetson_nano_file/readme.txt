how to run web server : 
python3 app.py

how to run iot motor system :
python3 main.py

how to run tunnel :
python3 ngrok.py