import pin_set
import time 
import get_fire

# pin_set.forward()
# time.sleep(3)
# pin_set.backward()
# time.sleep(3)
# pin_set.left()
# time.sleep(3)
# pin_set.right()
# time.sleep(3)
# pin_set.stop()

## data from firebase 
# 1 = forward
# 2 = right
# 3 = left
# 4 =  backward
# 0 = stop

s = get_fire.fire("/home/lutfi/program_kp/rbo1-5778c-firebase-adminsdk-h63az-36a1ec0554.json")
while 1 :
    if(s.get() == '1'):
        pin_set.forward()
        
    elif(s.get() == '2'):
        pin_set.right()
        
    elif(s.get() == '3'):
        pin_set.left()
        
    elif(s.get() == '4'):
        pin_set.backward()
        
    else:
        pin_set.stop()
        
    