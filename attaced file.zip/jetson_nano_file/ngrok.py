import os
import subprocess
import time
import json
import get_fire
import netifaces

while 1:
  try:	
    address = netifaces.ifaddresses('wlan0')

    
    print(address)
    break
  except:
    print("error")
    pass
time.sleep(5)
subprocess.Popen(['ngrok', 'http', '8080'])
time.sleep(3)
os.system("curl  http://localhost:4040/api/tunnels > tunnels.json")
s = get_fire.fire("/home/lutfi/program_kp/rbo1-5778c-firebase-adminsdk-h63az-36a1ec0554.json")
with open('tunnels.json') as data_file:    
    datajson = json.load(data_file)


msg = ''
for i in datajson['tunnels']:
  msg = msg + i['public_url'] +'\n'
msg,_,_ = msg.split("\n")
print(msg)
s.send('url',msg)
s.send('commnet','sdsdsdsds')
