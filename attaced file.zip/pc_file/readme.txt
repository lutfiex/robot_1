how to run: 
python3 app.py


