import cv2
from datetime import datetime
class VideoCamera(object):
    def __init__(self):
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.org = (50, 150)
        self.color = (255, 0, 0)
        self.thickness = 2
        self.fontScale = 1
        self.video = cv2.VideoCapture("http://192.168.33.41:8080/video_feed.jpg")
        

    def __del__(self):
        self.video.release()        

    def get_frame(self):
        ret, frame = self.video.read()
        t3 = "t3 :" + str(datetime.now())
        frame = cv2.putText(frame, t3, self.org, self.font, self.fontScale, self.color)

        ret, jpeg = cv2.imencode('.jpeg', frame)
        
        
        return jpeg.tobytes()